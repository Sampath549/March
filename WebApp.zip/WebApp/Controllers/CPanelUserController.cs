﻿using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WebApp.App_Start;
using WebApp.Filters;
using WebApp.Helper;
using WebApp.Models.SharedEntities;

namespace WebApp.Controllers
{
    [MVCSessionFilter, MVCUserAuthorization]
    public class CPanelUserController : Controller
    {
        #region Global Variables
        //SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
        #endregion

        #region Dashboard
        public ActionResult Dashboard()
        {
            try
            {
                ViewBag.DisplayModalPopup = Reusable.CheckIsFirstTimeLogin();   // Model PopUp   
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
            return View();
        }
        #endregion

        #region Accommodation
        public ActionResult AccommodationPosts()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                //API Call		
                ArrayList _Array = new ArrayList();
                string response = ApiHelper.PostData_Json("api/CPanelUser/GridPosts?Values=", _Array);
                Result<List<SE_Accommodation>> _Result = JsonConvert.DeserializeObject<Result<List<SE_Accommodation>>>(response);

                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        public ActionResult ViewAccPosts()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }

        public ActionResult AddAccPosts()
        {
            var model = new SE_Menus();
            ArrayList _Array = new ArrayList();

            ViewBag.AccPRoomTypes = Reusable.RoomTypes();

            string _States = ApiHelper.PostData_Json("api/Shared/GetStates?Values=", _Array);
            Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);
            ViewBag.AccPStates = Reusable.StatesList(_ResultStates);

            string _Countries = ApiHelper.PostData_Json("api/Shared/GetCountries?Values=", _Array);
            Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);
            ViewBag.AccPCountries = Reusable.CountriesList(_ResultCountries);

            return View("../PartialViews/AddAccPosts");
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult InsertAccPosts(SE_Accommodation _Posts)
        {
            try
            {
                //Server-Side Validations
                if (_Posts.Title == null || Sanitizer.GetSafeHtmlFragment(_Posts.Title) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Posts.Title).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Title should not be Empty and must have Min of 3 & Max of 30 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.RoomType == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.RoomType)) == "")
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.Address == null || Sanitizer.GetSafeHtmlFragment(_Posts.Address) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Address).Length > 50 || Sanitizer.GetSafeHtmlFragment(_Posts.Address).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Address should not be Empty and must have Min of 3 & Max of 50 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.City == null || Sanitizer.GetSafeHtmlFragment(_Posts.City) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length > 30 || Sanitizer.GetSafeHtmlFragment(_Posts.City).Length < 2)
                    return Json(new Result(false, 500, "Validation Error", "City should not be Empty and must have Min of 2 & Max of 30 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.StateId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.StateId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.CountryId == null || Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.CountryId)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Parent Menu"), JsonRequestBehavior.AllowGet);
                if (_Posts.ZipCode == null || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.ZipCode).Length > 10 || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Convert.ToString(_Posts.ZipCode)), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "ZipCode should not be Empty and must contain only Numbers with Max of 10 Characters"), JsonRequestBehavior.AllowGet);
                if (_Posts.Description == null || Sanitizer.GetSafeHtmlFragment(_Posts.Description) == "" || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length > 300 || Sanitizer.GetSafeHtmlFragment(_Posts.Description).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Description should not be Empty and must have Min of 3 & Max of 300 Characters"), JsonRequestBehavior.AllowGet);

                SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
                _Posts.UserId = _SessionUserDetails.UserId;

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Posts);
                string response = ApiHelper.PostData_Json("api/CPanelUser/InsertAccPosts?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult AccommodationRequests()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }
        #endregion
    }
}