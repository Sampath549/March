﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WebApp.App_Start;
using WebApp.Filters;
using WebApp.Helper;
using WebApp.Models.SharedEntities;
using Microsoft.Security.Application;
using System.Web.Security;

namespace WebApp.Controllers
{
    [MVCSessionFilter]
    public class CPanelController : Controller
    {
        #region Global Variables
        SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
        #endregion

        #region One Time Password
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult OneTimePassword(string OldPassword, string Password, string CPassword)
        {
            var score = 0;
            try
            {
                //Server-Side Validations		
                if (OldPassword == null || Sanitizer.GetSafeHtmlFragment(OldPassword) == "" || Sanitizer.GetSafeHtmlFragment(OldPassword).Length < 8 || Sanitizer.GetSafeHtmlFragment(OldPassword).Length > 50)
                    return Json(new Result(false, 500, "Validation Error", "Old Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password.Length >= 8 && Password.Length < 50)
                {
                    score = 0;

                    if (Regex.Match(Password, @"\d", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[a-z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[A-Z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[!,@,#,$,%,^,&,*,?,_,~,-,£,(,),\s]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (score < 4)
                        return Json(new Result(false, 500, "Validation Error", "New Password should contain minmum 1 Upper character, 1 Lower character, 1 Number and 1 Special character."), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password != CPassword)
                    return Json(new Result(false, 500, "Validation Error", "Password and Confirm Password should be same"), JsonRequestBehavior.AllowGet);

                //RSA Encryption		
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(OldPassword));
                _Val.Add(RSAPattern.Encrypt(Password));
                _Val.Add(RSAPattern.Encrypt(_SessionUserDetails.UserId.ToString()));

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanel/OneTimePassword?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                if (_Result.Status == true)
                {
                    SessionHandler.AuthPwd = Password;
                    _SessionUserDetails.IsFirstTimeLogin = false;
                    SessionHandler.UserDetails = _SessionUserDetails;
                }

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result(false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region User Details (My Profile, Change Password)
        public ActionResult MyProfile()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus

                ArrayList _Array = new ArrayList();
                string _Countries = ApiHelper.PostData_Json("api/Shared/GetCountries?Values=", _Array);
                Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);
                ViewBag.PCountries = Reusable.CountriesList(_ResultCountries);
                ViewBag.CCountries = Reusable.CountriesList(_ResultCountries);

                string _States = ApiHelper.PostData_Json("api/Shared/GetStates?Values=", _Array);
                Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);
                ViewBag.PStates = Reusable.StatesList(_ResultStates);
                ViewBag.CStates = Reusable.StatesList(_ResultStates);

                ViewBag.Gender_ddl = Reusable.GenderList();

                //API Call for User Mapping Details
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(_SessionUserDetails.EmailCheck));

                //API Call		
                ArrayList _ArrayUMDetails = new ArrayList();
                _ArrayUMDetails.Add(_Val);
                string response = ApiHelper.PostData_Json("api/CPanel/UserMappingDetails?Values=", _ArrayUMDetails);
                Result<SE_MyProfile> _Result = JsonConvert.DeserializeObject<Result<SE_MyProfile>>(response);

                SE_MyProfile _UserMapping = new SE_MyProfile();
                _UserMapping.FirstName = _SessionUserDetails.FirstName;
                _UserMapping.LastName = _SessionUserDetails.LastName;
                _UserMapping.EmailCheck = _SessionUserDetails.EmailCheck;
                _UserMapping.MobileCheck = _SessionUserDetails.MobileCheck;
                _UserMapping.RoleCode = _SessionUserDetails.RoleCode;
                if (_Result.Data.Gender != null)
                    _UserMapping.Gender = RSAPattern.Decrypt(_Result.Data.Gender);
                if (_Result.Data.ProfilePic != null)
                    _UserMapping.ProfilePic = _Result.Data.ProfilePic;
                if (_Result.Data.ImgType != null)
                    _UserMapping.ImgType = _Result.Data.ImgType;
                if (_Result.Data.isCurrentPermanent != null)
                    _UserMapping.isCurrentPermanent = _Result.Data.isCurrentPermanent;
                if (_Result.Data.PAddress != null)
                    _UserMapping.PAddress = RSAPattern.Decrypt(_Result.Data.PAddress);
                if (_Result.Data.PCity != null)
                    _UserMapping.PCity = RSAPattern.Decrypt(_Result.Data.PCity);
                if (_Result.Data.PStateId != null)
                    _UserMapping.PStateId = _Result.Data.PStateId;
                if (_Result.Data.PCountryId != null)
                    _UserMapping.PCountryId = _Result.Data.PCountryId;
                if (_Result.Data.PZipCode != null)
                    _UserMapping.PZipCode = RSAPattern.Decrypt(_Result.Data.PZipCode);
                if (_Result.Data.CAddress != null)
                    _UserMapping.CAddress = RSAPattern.Decrypt(_Result.Data.CAddress);
                if (_Result.Data.CCity != null)
                    _UserMapping.CCity = RSAPattern.Decrypt(_Result.Data.CCity);
                if (_Result.Data.CStateId != null)
                    _UserMapping.CStateId = _Result.Data.CStateId;
                if (_Result.Data.CCountryId != null)
                    _UserMapping.CCountryId = _Result.Data.CCountryId;
                if (_Result.Data.CZipCode != null)
                    _UserMapping.CZipCode = RSAPattern.Decrypt(_Result.Data.CZipCode);
                _UserMapping.ProfilePic = _Result.Data.ProfilePic;
                if (_Result.Data.ImgType != null)
                    _UserMapping.ImgType = _Result.Data.ImgType;

                return View(_UserMapping);
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult MyProfile(SE_MyProfile UserDetails)
        {
            SE_MyProfile _Usr = new SE_MyProfile();
            try
            {
                //Server-Side Validations
                if (UserDetails.FirstName == null || Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.FirstName).Length > 35)
                    return Json(new Result(false, 500, "Validation Error", "FirstName should not be Empty and must contain only Alphabets with not more than of 35 characters"), JsonRequestBehavior.AllowGet);
                if (UserDetails.LastName == null || Sanitizer.GetSafeHtmlFragment(UserDetails.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(UserDetails.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(UserDetails.LastName).Length > 35)
                    return Json(new Result(false, 500, "Validation Error", "LastName should not be Empty and must contain only Alphabets with not more than of 35 characters"), JsonRequestBehavior.AllowGet);

                if (UserDetails.ProfilePic != null)
                {
                    List<string> _ext = Reusable.ProfilePicExtentions();
                    if (!_ext.Contains(UserDetails.ImgType))
                        return Json(new Result(false, 500, "Validation Error", "Upload Images of Extentions .JPG, .JPEG, .PNG"), JsonRequestBehavior.AllowGet);
                }

                //RSA Encryption	                
                _Usr.FirstName = RSAPattern.Encrypt(UserDetails.FirstName);
                _Usr.LastName = RSAPattern.Encrypt(UserDetails.LastName);
                _Usr.EmailCheck = RSAPattern.Encrypt(_SessionUserDetails.EmailCheck);
                if (UserDetails.Gender != "0")
                    _Usr.Gender = RSAPattern.Encrypt(UserDetails.Gender);
                if (UserDetails.PAddress != null)
                    _Usr.PAddress = RSAPattern.Encrypt(UserDetails.PAddress);
                if (UserDetails.PCity != null)
                    _Usr.PCity = RSAPattern.Encrypt(UserDetails.PCity);
                if (UserDetails.PStateId != "0")
                    _Usr.PStateId = RSAPattern.Encrypt(UserDetails.PStateId);
                if (UserDetails.PCountryId != "0")
                    _Usr.PCountryId = RSAPattern.Encrypt(UserDetails.PCountryId);
                if (UserDetails.PZipCode != null)
                    _Usr.PZipCode = RSAPattern.Encrypt(UserDetails.PZipCode);
                _Usr.isCurrentPermanent = UserDetails.isCurrentPermanent;
                if (!Convert.ToBoolean(UserDetails.isCurrentPermanent))
                {
                    if (UserDetails.CAddress != null)
                        _Usr.CAddress = RSAPattern.Encrypt(UserDetails.CAddress);
                    if (UserDetails.CCity != null)
                        _Usr.CCity = RSAPattern.Encrypt(UserDetails.CCity);
                    if (UserDetails.CStateId != "0")
                        _Usr.CStateId = RSAPattern.Encrypt(UserDetails.CStateId);
                    if (UserDetails.CCountryId != "0")
                        _Usr.CCountryId = RSAPattern.Encrypt(UserDetails.CCountryId);
                    if (UserDetails.CZipCode != null)
                        _Usr.CZipCode = RSAPattern.Encrypt(UserDetails.CZipCode);
                }
                _Usr.ProfilePic = UserDetails.ProfilePic;
                if (UserDetails.ImgType != null)
                    _Usr.ImgType = RSAPattern.Encrypt(UserDetails.ImgType);

                //API Call		
                ArrayList _Array = new ArrayList();
                _Array.Add(_Usr);
                string response = ApiHelper.PostData_Json("api/CPanel/MyProfile?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                {
                    string FullName = UserDetails.FirstName + " " + UserDetails.LastName;
                    SessionHandler.WelcomeNameTitle = FullName;
                    if (FullName.Length > 25)
                        FullName = FullName.Substring(0, 25) + "...";
                    SessionHandler.WelcomeName = FullName;

                    if (UserDetails.ProfilePic != null)
                        SessionHandler.ProfilePic = UserDetails.ProfilePic;

                    _SessionUserDetails.FirstName = UserDetails.FirstName;
                    _SessionUserDetails.LastName = UserDetails.LastName;
                    SessionHandler.UserDetails = _SessionUserDetails;
                }

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                StatusCode.ErrorMsgText(ex);
                return Json(new { aaData = new List<string[]> { } }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ChangePassword()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        #endregion

        #region Manual Logout
        [HttpGet]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();

            System.Web.HttpContext.Current.Session.Clear();
            System.Web.HttpContext.Current.Session.RemoveAll();
            System.Web.HttpContext.Current.Session.Abandon();

            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Expires = DateTime.Now.AddYears(-1);
            cookie1.Secure = true;
            cookie1.HttpOnly = true;
            cookie1.Path += ";SameSite=Strict";
            System.Web.HttpContext.Current.Response.Cookies.Add(cookie1);

            HttpCookie cookie2 = new HttpCookie("s", "");
            cookie2.Expires = DateTime.Now.AddYears(-1);
            cookie2.Secure = true;
            cookie2.HttpOnly = true;
            cookie2.Path += ";SameSite=Strict";
            System.Web.HttpContext.Current.Response.Cookies.Add(cookie2);

            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
            if (Request.Cookies["ASP.NET_SessionId"] != null)
            {
                Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
            }

            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            SessionHandler.UserDetails = null;
            SessionHandler.AuthName = null;
            SessionHandler.AuthPwd = null;
            SessionHandler.WelcomeNameTitle = null;
            SessionHandler.WelcomeName = null;
            SessionHandler.ProfilePic = null;
            SessionHandler.Menus = null;

            return RedirectToAction("LoginPage", "Login");
        }
        #endregion

        #region Session Logout
        [HttpGet]
        public ActionResult SessionLogout()
        {
            bool result = false;
            try
            {
                FormsAuthentication.SignOut();

                System.Web.HttpContext.Current.Session.Clear();
                System.Web.HttpContext.Current.Session.RemoveAll();
                System.Web.HttpContext.Current.Session.Abandon();

                HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
                cookie1.Expires = DateTime.Now.AddYears(-1);
                cookie1.Secure = true;
                cookie1.HttpOnly = true;
                cookie1.Path += ";SameSite=Strict";
                System.Web.HttpContext.Current.Response.Cookies.Add(cookie1);

                HttpCookie cookie2 = new HttpCookie("s", "");
                cookie2.Expires = DateTime.Now.AddYears(-1);
                cookie2.Secure = true;
                cookie2.HttpOnly = true;
                cookie2.Path += ";SameSite=Strict";
                System.Web.HttpContext.Current.Response.Cookies.Add(cookie2);

                Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));
                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                }

                Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
                Response.Cache.SetNoStore();

                SessionHandler.UserDetails = null;
                SessionHandler.AuthName = null;
                SessionHandler.AuthPwd = null;
                SessionHandler.WelcomeNameTitle = null;
                SessionHandler.WelcomeName = null;
                SessionHandler.ProfilePic = null;
                SessionHandler.Menus = null;

                result = true;
            }
            catch
            {
                result = false;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}