﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Helper
{
    public class Result
    {
        public Result(bool success, int statuscode, string caption, string message)
        {
            this.Status = success;
            this.StatusCode = statuscode;
            this.Caption = caption;
            this.Message = message;
        }
        public bool Status { get; set; }
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public string Caption { get; set; }
        public static Result Success(int statuscode, string caption = null, string message = null)
        {
            return new Result(true, statuscode, caption, message);
        }
        public static Result Failed(int statuscode, string caption, string message = null)
        {
            return new Result(false, statuscode, caption, message);
        }
        public static Result<T> Success<T>(T data, int statuscode, string caption, string message = null)
        {
            return new Result<T>(data, true, statuscode, caption, message);
        }
        public static Result<T> Failed<T>(T data, int statuscode, string caption, string message = null)
        {
            return new Result<T>(data, false, statuscode, caption, message);
        }
    }
    public class Result<T> : Result
    {
        public Result(T data, bool success, int statuscode, string caption, string message)
            : base(success, statuscode, caption, message)
        {
            this.Data = data;
        }
        public T Data { get; set; }
    }
}