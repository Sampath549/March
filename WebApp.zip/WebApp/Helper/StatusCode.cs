﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace WebApp.Helper
{
    public class StatusCode
    {
        public static string ErrorPage(WebException ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);

            var response = ex.Response as HttpWebResponse;
            var StatusCode = response != null ? (int?)response.StatusCode : 0;
            string _PageRedirect = string.Empty;

            switch (StatusCode)
            {
                case 400:
                    _PageRedirect = GlobalVariables.Shared.BadRequest;
                    break;
                case 401:
                    _PageRedirect = GlobalVariables.Shared.Unauthorized;
                    break;
                case 403:
                    _PageRedirect = GlobalVariables.Shared.Forbidden;
                    break;
                case 404:
                    _PageRedirect = GlobalVariables.Shared.NotFound;
                    break;
                case 500:
                    _PageRedirect = GlobalVariables.Shared.InternalServerError;
                    break;
                default:
                    _PageRedirect = GlobalVariables.Shared.InternalServerError;
                    break;
            }
            return _PageRedirect;
        }
        public static string JsonError(WebException ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);

            var response = ex.Response as HttpWebResponse;
            var StatusCode = response != null ? (int?)response.StatusCode : 0;
            string _Values = string.Empty;

            switch (StatusCode)
            {
                case 400:
                    _Values = StatusCode.ToString() + '^' + "Bad Request";
                    break;
                case 401:
                    _Values = StatusCode.ToString() + '^' + "Unauthorized"; ;
                    break;
                case 403:
                    _Values = StatusCode.ToString() + '^' + "Forbidden";
                    break;
                case 404:
                    _Values = StatusCode.ToString() + '^' + "Not Found";
                    break;
                case 500:
                    _Values = StatusCode.ToString() + '^' + "Internal Server Error";
                    break;
                default:
                    _Values = "500" + '^' + "Internal Server Error";
                    break;
            }
            return _Values;
        }
        public static void ErrorMsgText(WebException ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);
        }
    }
}