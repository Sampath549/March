﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Models.SharedEntities
{
    public class SE_SubMenus
    {
        public int? ChildId { get; set; }
        public int? ParentId { get; set; }
        public string ParentHeader { get; set; }
        public IEnumerable<SelectListItem> ParentMenus { get; set; } // Only in WebApp
        public string Header { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public int? Order { get; set; }
        public string Title { get; set; }
    }
}