﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models.SharedEntities
{
    public class SE_Menus
    {
        public int? ParentId { get; set; }
        public string Header { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public bool HavingChild { get; set; }
        public int? Order { get; set; }
        public string Icon { get; set; }
        public string Title { get; set; }
    }
}