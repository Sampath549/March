﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;

namespace WebApp.Helper
{
    public static class ApiHelper
    {
        public static string GetDataParam_String_NToken(string endPointAddress, string _StringVal)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(GlobalVariables.Shared.ApiUrl);
                    client.DefaultRequestHeaders.Clear();
                    var response = client.GetAsync(endPointAddress + _StringVal);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
                        return requestResult;
                    }
                    else
                    {
                        var resp = new HttpResponseMessage(response.Result.StatusCode)
                        {
                            Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
                            ReasonPhrase = response.Result.ReasonPhrase
                        };
                        string[] _Values = resp.ToString().Split(new string[] { "StatusCode:", "," }, StringSplitOptions.RemoveEmptyEntries);
                        throw new WebException(_Values[0].Trim().ToString(), null, WebExceptionStatus.ProtocolError, null);
                    }
                }
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static string PostData_Json(string endPointAddress, ArrayList _Array)
        {
            try
            {
                var accessToken = OAuthHelper.AccessToken();

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(GlobalVariables.Shared.ApiUrl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                    var response = client.PostAsJsonAsync(endPointAddress, _Array);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
                        return requestResult;
                    }
                    else
                    {
                        var resp = new HttpResponseMessage(response.Result.StatusCode)
                        {
                            Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
                            ReasonPhrase = response.Result.ReasonPhrase
                        };
                        string[] _Values = resp.ToString().Split(new string[] { "StatusCode:", "," }, StringSplitOptions.RemoveEmptyEntries);
                        throw new WebException(_Values[0].Trim().ToString(), null, WebExceptionStatus.ProtocolError, null);
                    }
                }
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public static string PostData_Json_NToken(string endPointAddress, ArrayList _Array)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(GlobalVariables.Shared.ApiUrl);
                    client.DefaultRequestHeaders.Clear();
                    var response = client.PostAsJsonAsync(endPointAddress, _Array);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
                        return requestResult;
                    }
                    else
                    {
                        var resp = new HttpResponseMessage(response.Result.StatusCode)
                        {
                            Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
                            ReasonPhrase = response.Result.ReasonPhrase
                        };
                        string[] _Values = resp.ToString().Split(new string[] { "StatusCode:", "," }, StringSplitOptions.RemoveEmptyEntries);
                        throw new WebException(_Values[0].Trim().ToString(), null, WebExceptionStatus.ProtocolError, null);
                    }
                }
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }

        #region Commented Code
        //public static string GetData(string requestUriString, string _JsonString)
        //{
        //    var actual = "";
        //    try
        //    {
        //        var baseUri = GlobalVariables.Shared.ApiUrl;
        //        var accessToken = OAuthHelper.AccessToken();
        //        var request = WebRequest.Create(baseUri + requestUriString);
        //        request.Method = "Get";
        //        request.ContentType = "application/json";
        //        ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
        //        HttpWebResponse response;
        //        request.Headers.Add("Authorization", "Bearer " + accessToken);

        //        try
        //        {
        //            response = request.GetResponse() as HttpWebResponse;
        //            if (response.StatusCode == HttpStatusCode.OK)
        //                actual = response != null ? UnPackResponse(response) : "";
        //            else
        //            {
        //                var resp = new HttpResponseMessage(response.StatusCode)
        //                {
        //                    Content = new StringContent(UnPackResponse(response)),
        //                    ReasonPhrase = response.StatusDescription
        //                };
        //                throw new Exception(resp.ReasonPhrase);
        //                //throw new HttpResponseException(resp);
        //            }
        //        }
        //        catch (WebException ex)
        //        {
        //            response = ex.Response as HttpWebResponse;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        string message = ex.ToString();
        //    }
        //    return actual;
        //}
        //public static string GetParamData1(string endPointAddress, string _JsonString)
        //{
        //    try
        //    {
        //        var accessToken = OAuthHelper.AccessToken();
        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri(GlobalVariables.Shared.ApiUrl);
        //            client.DefaultRequestHeaders.Clear();
        //            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
        //            var response = client.GetAsync(endPointAddress + _JsonString);
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
        //                return requestResult;
        //            }
        //            else
        //            {
        //                var resp = new HttpResponseMessage(response.Result.StatusCode)
        //                {
        //                    Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
        //                    ReasonPhrase = response.Result.ReasonPhrase
        //                };
        //                throw new Exception(resp.ReasonPhrase);
        //                //throw new HttpResponseException(resp);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public static string GetDataParam_Json(string endPointAddress, ArrayList _Array)
        //{
        //    try
        //    {
        //        var accessToken = OAuthHelper.AccessToken();

        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri(GlobalVariables.Shared.ApiUrl);
        //            client.DefaultRequestHeaders.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        //            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
        //            var response = client.GetAsync(endPointAddress + _Array);
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
        //                return requestResult;
        //            }
        //            else
        //            {
        //                var resp = new HttpResponseMessage(response.Result.StatusCode)
        //                {
        //                    Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
        //                    ReasonPhrase = response.Result.ReasonPhrase
        //                };
        //                throw new HttpResponseException(resp);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public static string PostData(string endPointAddress, string strContent, bool isBearerRequired)
        //{
        //    var accessToken = isBearerRequired ? OAuthHelper.AccessToken : "";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri(GlobalVariables.Instance.ApiUrl);
        //            client.DefaultRequestHeaders.Clear();
        //            var authorizationheader = "";

        //            if (isBearerRequired)
        //                authorizationheader = "Bearer " + accessToken;
        //            else
        //                authorizationheader = "Basic " + GlobalVariables.Instance.ClientId + ":" + GlobalVariables.Instance.Secret;

        //            client.DefaultRequestHeaders.Add("Authorization", authorizationheader);
        //            var response = client.PostAsync(endPointAddress, new StringContent(strContent, Encoding.Default, "application/json"));
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
        //                return requestResult;
        //            }
        //            else
        //            {
        //                var resp = new HttpResponseMessage(response.Result.StatusCode)
        //                {
        //                    Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
        //                    ReasonPhrase = response.Result.ReasonPhrase
        //                };
        //                throw new HttpResponseException(resp);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public static string PutData(string endPointAddress, string _JsonString)
        //{
        //    var accessToken = OAuthHelper.AccessToken();
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri(GlobalVariables.Instance.ApiUrl);
        //            client.DefaultRequestHeaders.Clear();
        //            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
        //            var response = client.PutAsync(endPointAddress, new StringContent(_JsonString, Encoding.Default, "application/json"));
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
        //                return requestResult;
        //            }
        //            else
        //            {
        //                var resp = new HttpResponseMessage(response.Result.StatusCode)
        //                {
        //                    Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
        //                    ReasonPhrase = response.Result.ReasonPhrase
        //                };
        //                throw new Exception(resp.ReasonPhrase);
        //                //throw new HttpResponseException(resp);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public static string DeleteData(string endPointAddress, string _JsonString)
        //{
        //    var accessToken = OAuthHelper.AccessToken();
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri(GlobalVariables.Instance.ApiUrl);
        //            client.DefaultRequestHeaders.Clear();
        //            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
        //            var response = client.DeleteAsync(endPointAddress);
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                dynamic requestResult = response.Result.Content.ReadAsStringAsync().Result;
        //                return requestResult;
        //            }
        //            else
        //            {
        //                var resp = new HttpResponseMessage(response.Result.StatusCode)
        //                {
        //                    Content = new StringContent(response.Result.Content.ReadAsStringAsync().Result),
        //                    ReasonPhrase = response.Result.ReasonPhrase
        //                };
        //                throw new Exception(resp.ReasonPhrase);
        //                //throw new HttpResponseException(resp);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //private static string UnPackResponse(WebResponse response)
        //{
        //    var dataStream = response.GetResponseStream();
        //    if (dataStream == null) return "";
        //    var reader = new StreamReader(dataStream);
        //    return reader.ReadToEnd();
        //}
        #endregion
    }
}