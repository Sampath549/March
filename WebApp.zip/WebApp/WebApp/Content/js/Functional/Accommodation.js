﻿$(document).ready(function () {
    $("#btnAccPostsRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateAccPostsData').html(data);
            $('#CreateAccPostsModel').modal('show');
        });
    });
});