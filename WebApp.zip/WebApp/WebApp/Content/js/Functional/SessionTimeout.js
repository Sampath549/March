﻿$(document).ready(function () {
    $('#SessionPopupModel').modal('hide');

    var timeout;
    var myVar;
    document.onmousemove = resetTimer;
    document.onclick = resetTimer;

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(function () {
            $('#SessionPopupModel').modal('show');

            // Function to update counters on all elements with class counter
            var doUpdate = function () {
                $('.countdown').each(function () {
                    var count = parseInt($(this).html());
                    if (count !== 0) {
                        $(this).html(count - 1);
                    }
                    else {
                        $.ajax({
                            type: "GET",
                            url: "/CPanel/SessionLogout",
                            data: {},
                            dataType: "json",
                            success: function (response) {
                                if (response)
                                    window.location.href = "/Error/SessionExpired/";
                                else
                                    alert('Error')
                            },
                            error: function (xhr, ajaxOptions, thrownError) {
                                alert(xhr.responseText);
                            }
                        });
                    }
                });
            };
            // Schedule the update to happen once every second
            myVar = setInterval(doUpdate, 1000);
        }, 100 * 60 * 1000);
    }

    $("#btnContinue").click(function () {
        $('#SessionPopupModel').modal('hide');
        clearInterval(myVar);
        $(".countdown").html("60");
        clearTimeout(timeout);
    });
    $("#btnLogout").click(function () {
        $.ajax({
            type: "GET",
            url: "/CPanel/SessionLogout",
            data: {},
            dataType: "json",
            success: function (response) {
                if (response)
                    window.location.href = "/Error/SessionExpired/";
                else
                    alert('Error')
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    });
});