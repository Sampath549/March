﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Models.SharedEntities
{
    public class SE_States
    {
        public int Id { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public IEnumerable<SelectListItem> CountryList { get; set; } // Only in WebApp
        public string Code { get; set; }
        public string Description { get; set; }
    }
}