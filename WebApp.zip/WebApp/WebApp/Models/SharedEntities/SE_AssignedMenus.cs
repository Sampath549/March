﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Models.SharedEntities
{
    public class SE_AssignedMenus
    {
        public int? AssignedMenuId { get; set; }
        public int? ParentId { get; set; }
        public string ParentHeader { get; set; }
        public IEnumerable<SelectListItem> ParentMenus { get; set; } // Only in WebApp
        public int? RoleId { get; set; }
        public string RoleDesc { get; set; }
        public IEnumerable<SelectListItem> RoleList { get; set; } // Only in WebApp
    }
}