﻿using Microsoft.Security.Application;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Device.Location;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;
using WebApp.App_Start;
using WebApp.Helper;
using WebApp.Models.SharedEntities;

namespace WebApp.Controllers
{
    public class LoginController : Controller
    {
        #region Global Variables
        SE_Users Users;
        #endregion

        #region Design Pages for Login, Registration, ForgotPassword 
        // Note: 
        // 1) Content Security Policy for all the Startup pages.
        // 2) Error Redirecting to the Page depending on the status code. And can choose whether to insert in Error log text document or not.    

        [ContentSecurityPolicy]
        public ActionResult LoginPage()
        {
            try
            {
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult RegistrationPage()
        {
            try
            {
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }

        [ContentSecurityPolicy]
        public ActionResult ForgotPasswordPage()
        {
            try
            {
                return View();
            }
            catch (WebException ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
            }
        }
        #endregion

        #region POST Methods for Login, Registration, ForgotPassword
        // Note:
        // 1) CSRF AntiForgeryToken for all POST Methods.
        // 2) Error Message depending on the status code. And can choose whether to insert in Error log text document or not.  

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult LoginAuthentication(string _User, string _Password, string _ReCaptcha)
        {
            SessionHandler.UserDetails = null;
            SessionHandler.AuthName = null;
            SessionHandler.AuthPwd = null;
            SessionHandler.WelcomeNameTitle = null;
            SessionHandler.WelcomeName = null;
            SessionHandler.ProfilePic = null;
            SessionHandler.Menus = null;

            Users = new SE_Users();
            try
            {
                bool chk = isCaptchaValid(_ReCaptcha);
                if (!chk)
                    return Json(new Result<SE_Users>(Users, false, 500, "Validation Error", "ReCaptcha Validation Failed"), JsonRequestBehavior.AllowGet);

                //Server-Side Validations
                if (_User == null || Sanitizer.GetSafeHtmlFragment(_User) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User).Length > 75)
                    return Json(new Result<SE_Users>(Users, false, 500, "Validation Error", "Email should not be Empty and must be a Valid format"), JsonRequestBehavior.AllowGet);
                if (_Password == null || Sanitizer.GetSafeHtmlFragment(_Password) == "" || Sanitizer.GetSafeHtmlFragment(_Password).Length > 50)
                    return Json(new Result<SE_Users>(Users, false, 500, "Validation Error", "Password should not be Empty"), JsonRequestBehavior.AllowGet);

                //Access Token
                SessionHandler.AuthName = _User;
                SessionHandler.AuthPwd = _Password;

                //RSA Encryption
                Users = new SE_Users();
                Users.EmailCheck = RSAPattern.Encrypt(_User);
                Users.Password = RSAPattern.Encrypt(_Password);
                Users.IPAddress = Request.UserHostAddress;
                Users.EntryType = "";
                Users.EntryFrom = "Web";
                Users.BrowserName = Request.Browser.Browser;
                Users.BrowserVersion = Request.Browser.Version;
                Users.ResolutionWidth = Screen.PrimaryScreen.Bounds.Width.ToString();
                Users.ResolutionHeight = Screen.PrimaryScreen.Bounds.Height.ToString();
                string[] LatLon = GetLatLon().Split('^'); // GEO Location
                Users.Latitude = LatLon[0];
                Users.Longitude = LatLon[1];
                Users.Location = LatLon[2];

                //Audit
                ArrayList _ArrayAudit = new ArrayList();
                _ArrayAudit.Add(Users);
                string responseAudit = ApiHelper.PostData_Json_NToken("api/Login/Audit?Users=", _ArrayAudit);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json_NToken("api/Login/Login?Users=", _Array);
                Result<SE_Users> _Result = JsonConvert.DeserializeObject<Result<SE_Users>>(response);

                if (_Result.Data.Status == 1)
                {
                    _Result.Data.FirstName = RSAPattern.Decrypt(_Result.Data.FirstName);
                    _Result.Data.LastName = RSAPattern.Decrypt(_Result.Data.LastName);
                    _Result.Data.EmailCheck = RSAPattern.Decrypt(_Result.Data.EmailCheck);
                    _Result.Data.MobileCheck = RSAPattern.Decrypt(_Result.Data.MobileCheck);

                    string FullName = _Result.Data.FirstName + " " + _Result.Data.LastName;
                    SessionHandler.WelcomeNameTitle = FullName;
                    if (FullName.Length > 25)
                        FullName = FullName.Substring(0, 25) + "...";
                    SessionHandler.WelcomeName = FullName;

                    if (_Result.Data.ProfilePic != null)
                        SessionHandler.ProfilePic = _Result.Data.ProfilePic;

                    SessionHandler.UserDetails = _Result.Data;
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result<SE_Users>(_Result.Data, _Result.Status, _Result.StatusCode, _Result.Caption, _Result.Message), JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult RegistrationPage(SE_Users _User)
        {
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email);
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json_NToken("api/Login/Registration?Users=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult ForgotPasswordPage(string _Email)
        {
            try
            {
                //Server-Side Validations
                if (_Email == null || Sanitizer.GetSafeHtmlFragment(_Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                SE_SingleVal _Val = new SE_SingleVal();
                _Val.TextValue = RSAPattern.Encrypt(_Email);

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json_NToken("api/Login/ForgotPasswordLink?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Reset Password (View & POST)
        public ActionResult ResetPassword(string Value)
        {
            if (Sanitizer.GetSafeHtmlFragment(Value) != "" || Value != null)
            {
                DateTime CurrentDate = DateTime.Now;
                try
                {
                    var response = ApiHelper.GetDataParam_String_NToken("api/Login/GetLinkExpiryTime?StringVal=", Value);
                    string resultAdd = JsonConvert.DeserializeObject(response).ToString();
                    string[] _List = resultAdd.Split('^');

                    if (!Convert.ToBoolean(_List[1]))
                    {
                        int TotalTime = Convert.ToInt32(CurrentDate.Subtract(Convert.ToDateTime(_List[0])).TotalMinutes);
                        int ExpiryTime = GlobalVariables.Shared.EmailLinkExpiry;
                        if (TotalTime > ExpiryTime)
                            ViewBag.TimeExpired = true;
                        else
                            ViewBag.TimeExpired = false;
                        ViewBag.LinkClicked = false;
                    }
                    else
                        ViewBag.LinkClicked = true;
                }
                catch (WebException ex)
                {
                    return RedirectToAction(StatusCode.ErrorPage(ex), "Error");
                }
            }
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult ResetPassword(string Email, string Password, string CPassword, string GuidVal)
        {
            var score = 0;
            try
            {
                //Server-Side Validations
                if (Email == null || Sanitizer.GetSafeHtmlFragment(Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format"), JsonRequestBehavior.AllowGet);

                if (Password.Length >= 8 && Password.Length < 50)
                {
                    score = 0;

                    if (Regex.Match(Password, @"\d", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[a-z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[A-Z]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (Regex.Match(Password, @"[!,@,#,$,%,^,&,*,?,_,~,-,£,(,),\s]", RegexOptions.ECMAScript).Success)
                        score++;
                    if (score < 4)
                        return Json(new Result(false, 500, "Validation Error", "Password should contain minmum 1 Upper character, 1 Lower character, 1 Number and 1 Special character."), JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new Result(false, 500, "Validation Error", "Password should contain Min 8 & Max 50 Characters"), JsonRequestBehavior.AllowGet);

                if (Password != CPassword)
                    return Json(new Result(false, 500, "Validation Error", "Password and Confirm Password should be same"), JsonRequestBehavior.AllowGet);
                if (GuidVal == null || Sanitizer.GetSafeHtmlFragment(GuidVal) == "")
                    return Json(new Result(false, 500, "Validation Error", "Parameter value should not be Empty"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                List<string> _Val = new List<string>();
                _Val.Add(RSAPattern.Encrypt(Email));
                _Val.Add(RSAPattern.Encrypt(Password));
                _Val.Add(GuidVal.Replace(" ", "+"));

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(_Val);
                string response = ApiHelper.PostData_Json_NToken("api/Login/ResetPassword?Values=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (WebException ex)
            {
                string[] _Exception = StatusCode.JsonError(ex).Split('^');
                return Json(new Result<SE_Users>(Users, false, Convert.ToInt32(_Exception[0]), null, _Exception[1].ToString()), JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Private Functions
        private bool isCaptchaValid(string res)
        {
            var result = false;
            var captchaResponse = res;
            var secretKey = "6Le8IokUAAAAAJnKCaDOrbkMKVHaw9v1Cgq8GchF";
            var apiUrl = "https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}";
            var requestUri = string.Format(apiUrl, secretKey, captchaResponse);
            var request = (HttpWebRequest)WebRequest.Create(requestUri);

            using (WebResponse response = request.GetResponse())
            {
                using (StreamReader stream = new StreamReader(response.GetResponseStream()))
                {
                    JObject jResponse = JObject.Parse(stream.ReadToEnd());
                    var isSuccess = jResponse.Value<bool>("success");
                    result = (isSuccess) ? true : false;
                }
            }
            return result;
        }
        private string GetLatLon()
        {
            GeoCoordinateWatcher watcher = new GeoCoordinateWatcher();
            watcher.TryStart(false, TimeSpan.FromMilliseconds(5000));
            GeoCoordinate coord = watcher.Position.Location;
            if (!watcher.Position.Location.IsUnknown)
            {
                Users.Latitude = watcher.Position.Location.Latitude.ToString();
                Users.Longitude = watcher.Position.Location.Longitude.ToString();
                ////Sam Change Code
                //IGeocoder geocoder = new GoogleGeocoder(GlobalVariables.Shared.IPLocationAPIKey);
                //IEnumerable<Address> addresses = geocoder.ReverseGeocode(Convert.ToDouble(Users.Latitude), Convert.ToDouble(Users.Longitude));
                //Users.Location = ((Geocoding.Google.GoogleAddress[])(addresses))[0].FormattedAddress; 
                Users.Location = "";
            }
            else
            {
                GetLatLon();
            }
            watcher.Stop();
            return Users.Latitude + "^" + Users.Longitude + "^" + Users.Location;
        }
        #endregion
    }
}