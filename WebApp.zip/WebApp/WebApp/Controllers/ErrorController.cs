﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.Filters;
using WebApp.Helper;

namespace WebApp.Controllers
{
    public class ErrorController : Controller
    {
        [MVCSessionFilter]
        public ActionResult BadRequest()
        {
            if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                Reusable.BindMenus();
            ViewBag.Menus = SessionHandler.Menus;
            return View();
        }

        [MVCSessionFilter]
        public ActionResult Unauthorized()
        {
            if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                Reusable.BindMenus();
            ViewBag.Menus = SessionHandler.Menus;
            return View();
        }

        [MVCSessionFilter]
        public ActionResult Forbidden()
        {
            if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                Reusable.BindMenus();
            ViewBag.Menus = SessionHandler.Menus;
            return View();
        }

        [MVCSessionFilter]
        public ActionResult NotFound()
        {
            if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                Reusable.BindMenus();
            ViewBag.Menus = SessionHandler.Menus;
            return View();
        }

        [MVCSessionFilter]
        public ActionResult InternalServerError()
        {
            if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                Reusable.BindMenus();
            ViewBag.Menus = SessionHandler.Menus;
            return View();
        }

        public ActionResult SessionExpired()
        {
            return View();
        }
    }
}