﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.App_Start
{
    public class ContentSecurityPolicy : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string _ClientURL = ConfigurationManager.AppSettings["ConfigClientUrl"].ToString();

            var _Response = filterContext.HttpContext.Response;

            //Change Code
            //var _ProjectUrls = string.Join(
            //                               " ",
            //                               " " + _ClientURL + " "
            //                              );
            //var _FontUrls = string.Join(
            //                           " ",
            //                           "https://www.google.com/recaptcha/",
            //                           "https://www.gstatic.com/recaptcha/api2/",
            //                           " https://maps.googleapis.com/ "
            //                          );

            //StringBuilder sb = new StringBuilder();

            //sb.Append("default-src  'self' " + _ProjectUrls + " ;");
            //sb.Append("style-src 'self' 'unsafe-inline' " + _ProjectUrls + " ;");
            //sb.Append("script-src 'self' 'unsafe-inline' " + _ProjectUrls + " ;");
            //sb.Append("img-src 'self' 'unsafe-inline' " + _ProjectUrls + " ;");
            //sb.Append("font-src 'self' 'unsafe-inline' " + _FontUrls + " ;");
            //_Response.AddHeader("Content-Security-Policy", sb.ToString());

            //Sam Change Code
            //ifany problem with above line just comment the above lines from _ProjectUrls anduncomment the below line
            _Response.AddHeader("X-Content-Security-Policy", "script-src 'self'");
            _Response.AddHeader("X-WebKit-CSP", "script-src 'self'");
            _Response.AddHeader("Cache-Control", "no-cache, no-store, must-revalidate, pre-check=0, post-check=0, max-age=0, s-maxage=0");
            _Response.AddHeader("Expires", "-1");
            _Response.AddHeader("Pragma", "no-cache");

            base.OnActionExecuting(filterContext);
        }
    }
}