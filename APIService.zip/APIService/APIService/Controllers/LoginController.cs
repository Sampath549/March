﻿using APIService.Helper;
using APIService.Models;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIService.Controllers
{
    [RoutePrefix("api/Login")]
    public class LoginController : ApiController
    {
        SE_Users Users;
        LoginDAL _ObjLogin = new LoginDAL();
        SharedDAL _ObjShared = new SharedDAL();

        [HttpPost, Route("Registration")]
        public Result Registration(ArrayList Array)
        {
            try
            {
                Users = new SE_Users();
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                string ActualFName, ActualLName, ActualEmail, ActualMobile, RandomPwd, SaltKey = string.Empty;
                ActualFName = RSAPattern.Decrypt(Users.FirstName);
                ActualLName = RSAPattern.Decrypt(Users.LastName);
                ActualEmail = RSAPattern.Decrypt(Users.Email);
                ActualMobile = RSAPattern.Decrypt(Users.Mobile);
                RandomPwd = PwdEncryption.GeneratePassword();
                SaltKey = PwdEncryption.GeneratePassword();

                Users.PersonalKey = AES_Algorithm.EncryptString(Guid.NewGuid().ToString());
                Users.FirstName = AES_Algorithm.EncryptString(ActualFName);
                Users.LastName = AES_Algorithm.EncryptString(ActualLName);
                Users.Email = AES_Algorithm.EncryptString(ActualEmail);
                Users.EmailCheck = StringEncrypt.Encrypt(ActualEmail);
                Users.Mobile = AES_Algorithm.EncryptString(ActualMobile);
                Users.MobileCheck = StringEncrypt.Encrypt(ActualMobile);
                Users.RoleCode = GlobalVariables.Shared.UserRole;
                Users.SaltKey = AES_Algorithm.EncryptString(SaltKey);
                Users.Password = PwdEncryption.EncodePassword(RandomPwd, SaltKey);

                int _Status = _ObjLogin.InsertRegistration(Users);

                bool _SendMail = false;
                if (_Status == 1)
                {
                    EmailHelper _EmailHelper = EmailHelper.Instance;
                    string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + ActualFName + @" " + ActualLName + @"</b>..!!,</p>
                                            <p>Thank you for Joining EuroBharat. Here are the details.</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'> Email:</td>
                                                    <td style='border:0'><strong>" + ActualEmail + @"</strong></td>
                                                </tr>
                                                <tr>
                                                    <td style='border:0'> Password:</td>
                                                    <td style='border:0'><strong>" + RandomPwd + @"</strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                        <p style='margin-bottom: 0px'><strong> Important Note :</strong></p>
                                        <div style='margin-left:40px; margin-top: -15px; color:initial;'>
                                            <table style = 'border:0'>
                                                <tr>
                                                    <td style='border:0'>a. Please find the attached file for better understanding of EuroBharat.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                    List<EmailAttachment> _Attachments = new List<EmailAttachment>();
                    _Attachments.Add(new EmailAttachment("Welcome.pdf", File.ReadAllBytes(System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/Documents/Welcome.pdf"))));
                    string emailTo = string.Empty;
                    if (GlobalVariables.Shared._SendActualMails)
                        emailTo = ActualEmail;
                    else
                        emailTo = GlobalVariables.Shared._SendDefaultEmailTo;

                    _SendMail = _EmailHelper.SendWithTemplate(emailTo, "", "Welcome Email", _EmailHelper.HTMLSanitize(_MessageBody), _Attachments);
                }

                if (_Status == 1 && _SendMail == false)
                    return Result.Failed(500, "Email Sending Failed", "Registartion was Successful but Email Sending Failed");
                else if (_Status == 101)
                    return Result.Failed(500, "Duplicate Record", "Email / Mobile already exists");
                else
                    return Result.Success(200, "Success", "Registartion is Successful");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("Audit")]
        public Result<SE_Users> Audit(ArrayList ArrayAudit)
        {
            Users = new SE_Users();
            SE_Users _Result = new SE_Users();
            try
            {
                foreach (JObject val in ArrayAudit)
                    Users = val.ToObject<SE_Users>();

                string ActualEmail = RSAPattern.Decrypt(Users.EmailCheck);
                bool _Status = Convert.ToBoolean(_ObjLogin.TokenAuthentication(ActualEmail, RSAPattern.Decrypt(Users.Password)).Status);
                int UserIdEmail = _ObjLogin.GetUserIdByEmail(StringEncrypt.Encrypt(ActualEmail));

                bool AuditRec = _ObjLogin.InsertAuditLogin(UserIdEmail, Users.IPAddress, Users.EntryType, Users.EntryFrom, Users.BrowserName + " " + Users.BrowserVersion, Users.ResolutionWidth + "x" + Users.ResolutionHeight, Users.Location, Users.Latitude, Users.Longitude, _Status);
                if (!_Status && AuditRec)
                {
                    _ObjLogin.UpdateAttemptsFailed(UserIdEmail);
                    Users.FailedLoginAttempts = Users.FailedLoginAttempts + 1;
                }

                _Result.Status = Users.Status;
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("Login")]
        public Result<SE_Users> Login(ArrayList Array)
        {
            Users = new SE_Users();
            SE_Users _Result = new SE_Users();
            try
            {
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                string ActualEmail = RSAPattern.Decrypt(Users.EmailCheck);
                _Result = _ObjLogin.AuthenticatedUser(StringEncrypt.Encrypt(ActualEmail), PwdEncryption.EncodePassword(RSAPattern.Decrypt(Users.Password), AES_Algorithm.DecryptString(_ObjShared.GetSaltKeyByEmail(StringEncrypt.Encrypt(ActualEmail)))));
                _Result.RedirectUrl = Reusable.RedirectPage(_Result.RoleCode);
                if (_Result.RedirectUrl != null || _Result.RedirectUrl != "")
                {
                    _Result.FirstName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.FirstName));
                    _Result.LastName = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.LastName));
                    _Result.EmailCheck = RSAPattern.Encrypt(StringEncrypt.Decrypt(_Result.EmailCheck));
                    _Result.MobileCheck = RSAPattern.Encrypt(StringEncrypt.Decrypt(_Result.MobileCheck));

                    return Result.Success(_Result, 200, "Success", "Success");
                }
                else
                    return Result.Failed(_Result, 500, "Error", "Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("ForgotPasswordLink")]
        public Result ForgotPasswordLink(ArrayList Array)
        {
            SE_SingleVal _Val = new SE_SingleVal();
            try
            {
                foreach (JObject val in Array)
                    _Val = val.ToObject<SE_SingleVal>();

                string ActualEmail = string.Empty;
                ActualEmail = RSAPattern.Decrypt(_Val.TextValue);
                _Val.TextValue = StringEncrypt.Encrypt(ActualEmail);

                string GuidVal = AES_Algorithm.EncryptString(Guid.NewGuid().ToString().Trim());
                string _Status = _ObjLogin.GetFullNameByEmail(_Val.TextValue);

                bool _SendMail = false;
                if (_Status != null)
                {
                    int ResetLog = _ObjLogin.InsertResetPwdLog(GuidVal, _Val.TextValue);
                    if (ResetLog == 0)
                        return Result.Failed(500, "Error", "Internal Server Error");
                    if (ResetLog == 201)
                        return Result.Failed(500, "Duplicate Submission", "Reset Password Link has been already sent. Please wait for sometime and retry again.");

                    string[] FullName = _Status.Split('^');
                    string URL = GlobalVariables.Shared.ClientUrl + GlobalVariables.Shared._ResetPwdURL + GuidVal;
                    EmailHelper _EmailHelper = EmailHelper.Instance;
                    string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + AES_Algorithm.DecryptString(FullName[0]) + @" " + AES_Algorithm.DecryptString(FullName[1]) + @"</b>!!,</p>
                                            <p>We have created a link to Reset your Password. Please click on the below Link</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'><strong><a href=" + URL + @">Click Here</a></strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                    List<EmailAttachment> _Attachments = new List<EmailAttachment>();
                    string emailTo = string.Empty;
                    if (GlobalVariables.Shared._SendActualMails)
                        emailTo = ActualEmail;
                    else
                        emailTo = GlobalVariables.Shared._SendDefaultEmailTo;

                    _SendMail = _EmailHelper.SendWithTemplate(emailTo, "", "Reset Password", _EmailHelper.HTMLSanitize(_MessageBody), _Attachments);
                }
                else
                    return Result.Success(200, "Success", "Reset Password Link has been sent to your Registered email");

                if (_SendMail)
                    return Result.Success(200, "Success", "Reset Password Link has been sent to your Registered email");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpGet, Route("GetLinkExpiryTime")]
        public string GetLinkExpiryTime(string StringVal)
        {
            try
            {
                return _ObjLogin.GetExpiryDate_IsReset(StringVal.Replace(" ", "+"));
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("ResetPassword")]
        public Result ResetPassword(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string ActualEmail, EmailEncrypt = string.Empty;
                ActualEmail = RSAPattern.Decrypt(_lst[0]);
                EmailEncrypt = StringEncrypt.Encrypt(ActualEmail);

                string SaltKey = PwdEncryption.GeneratePassword();
                string NewPassword = PwdEncryption.EncodePassword(RSAPattern.Decrypt(_lst[1]), SaltKey);
                string NewSaltKey = AES_Algorithm.EncryptString(SaltKey);

                int _Result = _ObjLogin.ResetPassword(EmailEncrypt, NewPassword, NewSaltKey, _lst[2]);
                if (_Result == 1)
                    return Result.Success(200, "Success", "Email Sent Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Link Expired");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "Password Already Updated");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
    }
}
