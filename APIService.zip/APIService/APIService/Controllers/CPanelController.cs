﻿using APIService.Helper;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIService.Controllers
{
    [Authorize, RoutePrefix("api/CPanel")]
    public class CPanelController : ApiController
    {
        #region Global Variables
        CPanelDAL _ObjCPanel = new CPanelDAL();
        SharedDAL _ObjShared = new SharedDAL();
        #endregion

        #region One Time Password
        [HttpPost, Route("OneTimePassword")]
        public Result OneTimePassword(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string OldPassword, OldSaltKey, Password = string.Empty;
                Password = RSAPattern.Decrypt(_lst[1]);
                OldSaltKey = _ObjShared.GetSaltKeyById(RSAPattern.Decrypt(_lst[2]));
                OldPassword = PwdEncryption.EncodePassword(RSAPattern.Decrypt(_lst[0]), AES_Algorithm.DecryptString(OldSaltKey));

                string SaltKey = PwdEncryption.GeneratePassword();
                string NewPassword = PwdEncryption.EncodePassword(RSAPattern.Decrypt(_lst[1]), SaltKey);
                string NewSaltKey = AES_Algorithm.EncryptString(SaltKey);

                int _Result = _ObjCPanel.OneTimePassword(Convert.ToInt32(RSAPattern.Decrypt(_lst[2])), OldPassword, OldSaltKey, NewPassword, NewSaltKey);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Change Password is Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Incorrect Old Password");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "User does not Exists");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region Binding Navigation Menus
        [HttpPost, Route("BindMenus")]
        public Result<string> BindMenus(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string _Result = _ObjCPanel.GetMenus(RSAPattern.Decrypt(_lst[0]));
                _Result = _Result.Replace(Environment.NewLine, string.Empty).Trim();

                return Result.Success(_Result, 200, "Success", "Change Password is Succesfully");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion

        #region User Details
        [HttpPost, Route("MyProfile")]
        public Result MyProfile(ArrayList Array)
        {
            SE_MyProfile _Details = new SE_MyProfile();
            SE_MyProfile _Records = new SE_MyProfile();

            try
            {
                foreach (JObject val in Array)
                    _Details = val.ToObject<SE_MyProfile>();

                _Records.FirstName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.FirstName));
                _Records.LastName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.LastName));
                _Records.EmailCheck = StringEncrypt.Encrypt(RSAPattern.Decrypt(_Details.EmailCheck));

                if (_Details.Gender != null)
                    _Records.Gender = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.Gender));
                if (_Details.PAddress != null)
                    _Records.PAddress = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.PAddress));
                if (_Details.PCity != null)
                    _Records.PCity = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.PCity));
                if (_Details.PStateId != null)
                    _Records.PStateId = RSAPattern.Decrypt(_Details.PStateId);
                if (_Details.PCountryId != null)
                    _Records.PCountryId = RSAPattern.Decrypt(_Details.PCountryId);
                if (_Details.PZipCode != null)
                    _Records.PZipCode = RSAPattern.Decrypt(_Details.PZipCode);
                _Records.isCurrentPermanent = _Details.isCurrentPermanent;
                if (!Convert.ToBoolean(_Details.isCurrentPermanent))
                {
                    if (_Details.CAddress != null)
                        _Records.CAddress = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.CAddress));
                    if (_Details.CCity != null)
                        _Records.CCity = AES_Algorithm.EncryptString(RSAPattern.Decrypt(_Details.CCity));
                    if (_Details.CStateId != null)
                        _Records.CStateId = RSAPattern.Decrypt(_Details.CStateId);
                    if (_Details.CCountryId != null)
                        _Records.CCountryId = RSAPattern.Decrypt(_Details.CCountryId);
                    if (_Details.CZipCode != null)
                        _Records.CZipCode = RSAPattern.Decrypt(_Details.CZipCode);
                }
                _Records.ProfilePic = _Details.ProfilePic;
                if (_Details.ImgType != null)
                    _Records.ImgType = RSAPattern.Decrypt(_Details.ImgType);

                int _Result = _ObjCPanel.InsertUpdateMyProfile(_Records);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Details Updated Successfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("UserMappingDetails")]
        public Result<SE_MyProfile> UserMappingDetails(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            SE_MyProfile _Result = new SE_MyProfile();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                string ActualEmail = StringEncrypt.Encrypt(RSAPattern.Decrypt(_lst[0]));
                _Result = _ObjCPanel.UserMappingDetails(ActualEmail);

                if (_Result.Gender != null)
                    _Result.Gender = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.Gender));
                if (_Result.PAddress != null)
                    _Result.PAddress = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.PAddress));
                if (_Result.PCity != null)
                    _Result.PCity = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.PCity));
                if (_Result.PZipCode != null)
                    _Result.PZipCode = RSAPattern.Encrypt(_Result.PZipCode);
                if (_Result.CAddress != null)
                    _Result.CAddress = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.CAddress));
                if (_Result.CCity != null)
                    _Result.CCity = RSAPattern.Encrypt(AES_Algorithm.DecryptString(_Result.CCity));
                if (_Result.CZipCode != null)
                    _Result.CZipCode = RSAPattern.Encrypt(_Result.CZipCode);

                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion
    }
}
