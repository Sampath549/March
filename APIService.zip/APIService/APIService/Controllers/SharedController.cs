﻿using APIService.Helper;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIService.Controllers
{
    [RoutePrefix("api/Shared")]
    public class SharedController : ApiController
    {
        SharedDAL _ObjShared = new SharedDAL();

        [HttpPost, Route("GetCountries")]
        public Result<List<SE_RefValues>> GetCountries(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.GetCountries();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("GetStates")]
        public Result<List<SE_RefValues>> GetStates(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.GetStates();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [Authorize, HttpPost, Route("ParentMenus")]
        public Result<List<SE_RefValues>> ParentMenus(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.ParentMenus();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [Authorize, HttpPost, Route("RoleList")]
        public Result<List<SE_RefValues>> RoleList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjShared.RoleList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
    }
}
