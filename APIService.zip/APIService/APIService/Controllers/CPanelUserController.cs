﻿using APIService.Helper;
using APIService.Models.DataObjects;
using APIService.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIService.Controllers
{
    [Authorize(Roles = "USR"), RoutePrefix("api/CPanelUser")]
    public class CPanelUserController : ApiController
    {
        #region Global Variables
        CPanelUserDAL _ObjCPanelUser = new CPanelUserDAL();
        #endregion

        #region Sub Menus
        [HttpPost, Route("GridPosts")]
        public Result<List<SE_Accommodation>> GridPosts(ArrayList Array)
        {
            List<SE_Accommodation> _Result = new List<SE_Accommodation>();
            try
            {
                //foreach (JObject val in Array)
                //    _AccPosts = val.ToObject<SE_Accommodation>();

                _Result = _ObjCPanelUser.GridPosts();
                return Result.Success(_Result, 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("SinglePosts")]
        public Result<SE_Accommodation> SinglePosts(ArrayList Array)
        {
            List<string> _lst = new List<string>();
            List<SE_Accommodation> _Result = new List<SE_Accommodation>();
            try
            {
                foreach (JArray val in Array)
                    _lst = val.ToObject<List<string>>();

                _Result = _ObjCPanelUser.SinglePosts(Convert.ToInt32(_lst[0]));
                return Result.Success(_Result[0], 200, "Success", "Success");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }

        [HttpPost, Route("InsertAccPosts")]
        public Result InsertAccPosts(ArrayList Array)
        {
            SE_Accommodation _AccPosts = new SE_Accommodation();
            try
            {
                foreach (JObject val in Array)
                    _AccPosts = val.ToObject<SE_Accommodation>();

                int _Result = _ObjCPanelUser.InsertAccPosts(_AccPosts);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Inserted Succesfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (WebException ex)
            {
                Reusable.ErrorMsgText(ex);
                throw ex;
            }
        }
        #endregion
    }
}
