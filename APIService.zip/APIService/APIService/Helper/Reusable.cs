﻿using APIService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace APIService.Helper
{
    public static class Reusable
    {
        public static string RedirectPage(string RoleCode)
        {
            try
            {
                if (RoleCode == "DEV")
                    return "/CPanelDev/Dashboard";
                else if (RoleCode == "USR")
                    return "/CPanelUser/Dashboard";
                else if (RoleCode == "BUS")
                    return "";
                else if (RoleCode == "COMM")
                    return "";
                else if (RoleCode == "SA")
                    return "";
                else if (RoleCode == "ADM")
                    return "";
                else
                    return "";
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }

        public static void ErrorMsgText(WebException ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);
        }
    }
}