﻿using APIService.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;

namespace APIService.Models.DataObjects
{
    public partial class CPanelUserDAL : DataAccessComponent
    {
        public List<SE_Accommodation> GridPosts()
        {
            try
            {
                List<SE_Accommodation> _Rec = new List<SE_Accommodation>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                        SELECT 
	                                        AP.AccommodationPostId, 
	                                        AP.UserId,
                                            U.FirstName,
	                                        U.LastName,
	                                        AP.Title,
	                                        AP.RoomType,
	                                        AP.[Address],
	                                        AP.City,
	                                        AP.StateId,
	                                        S.[Description] [StateDesc],
	                                        C.[Description] [CountryDesc],
	                                        AP.CountryId,
	                                        AP.ZipCode,
	                                        AP.[Description],
	                                        AP.CreatedDate,
                                            (SELECT (SELECT DATENAME(DW,AP.CreatedDate))+', '+ DATENAME(MONTH, GETDATE())+ RIGHT(CONVERT(VARCHAR(200), AP.CreatedDate, 107), 9)) AS [DateLongString]
                                        FROM [eurodb].[tbl_AccommodationPosts] AP
                                        INNER JOIN [eurodb].[Ref_States] S ON AP.StateId = S.StateId
                                        INNER JOIN [eurodb].[Ref_Countries] C ON AP.CountryId = C.CountryId  
                                        INNER JOIN [eurodb].[tbl_Users] U ON AP.UserId = U.UserId              
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Accommodation { AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]), UserId = Convert.ToInt32(dr["UserId"]), Title = dr["Title"].ToString(), RoomType = dr["RoomType"].ToString(), Address = dr["Address"].ToString(), City = dr["City"].ToString(), StateId = dr["StateId"].ToString(), StateDesc = dr["StateDesc"].ToString(), CountryId = dr["CountryId"].ToString(), CountryDesc = dr["CountryDesc"].ToString(), ZipCode = dr["ZipCode"].ToString(), Description = dr["Description"].ToString(), CreatedDate = Convert.ToDateTime(dr["CreatedDate"]), DateLongString = dr["DateLongString"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }

        public List<SE_Accommodation> SinglePosts(int Id)
        {
            try
            {
                List<SE_Accommodation> _Rec = new List<SE_Accommodation>();
                DataSet _Result = new DataSet();
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        string _Query = @"
                                        SELECT 
	                                        AP.AccommodationPostId, 
	                                        AP.UserId,
                                            U.FirstName,
	                                        U.LastName,
	                                        AP.Title,
	                                        AP.RoomType,
	                                        AP.[Address],
	                                        AP.City,
	                                        AP.StateId,
	                                        S.[Description] [StateDesc],
	                                        C.[Description] [CountryDesc],
	                                        AP.CountryId,
	                                        AP.ZipCode,
	                                        AP.[Description],
	                                        AP.CreatedDate,
                                            (SELECT (SELECT DATENAME(DW,AP.CreatedDate))+', '+ DATENAME(MONTH, GETDATE())+ RIGHT(CONVERT(VARCHAR(200), AP.CreatedDate, 107), 9)) AS [DateLongString]
                                        FROM [eurodb].[tbl_AccommodationPosts] AP
                                        INNER JOIN [eurodb].[Ref_States] S ON AP.StateId = S.StateId
                                        INNER JOIN [eurodb].[Ref_Countries] C ON AP.CountryId = C.CountryId 
                                        INNER JOIN [eurodb].[tbl_Users] U ON AP.UserId = U.UserId
                                        WHERE AP.AccommodationPostId=@IDVal
                                        ";
                        da.SelectCommand = new SqlCommand(_Query, con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@IDVal", Id);
                        da.Fill(_Result);
                    }
                }

                if (_Result.Tables[0].Rows.Count > 0)
                    foreach (DataRow dr in _Result.Tables[0].Rows)
                        _Rec.Add(new SE_Accommodation { AccommodationId = Convert.ToInt32(dr["AccommodationPostId"]), UserId = Convert.ToInt32(dr["UserId"]), FirstName = dr["FirstName"].ToString(), LastName = dr["LastName"].ToString(), Title = dr["Title"].ToString(), RoomType = dr["RoomType"].ToString(), Address = dr["Address"].ToString(), City = dr["City"].ToString(), StateId = dr["StateId"].ToString(), StateDesc = dr["StateDesc"].ToString(), CountryId = dr["CountryId"].ToString(), CountryDesc = dr["CountryDesc"].ToString(), ZipCode = dr["ZipCode"].ToString(), Description = dr["Description"].ToString(), CreatedDate = Convert.ToDateTime(dr["CreatedDate"]), DateLongString = dr["DateLongString"].ToString() });

                return _Rec;
            }
            catch (WebException ex)
            {
                throw ex;
            }
        }
        public int InsertAccPosts(SE_Accommodation _AccPosts)
        {
            SqlConnection con = new SqlConnection(DB_ADOConnect);
            con.Open();
            int Status = 0;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_Insert_AccPosts";
                cmd.Parameters.Add("@UserId", SqlDbType.VarChar).Value = _AccPosts.UserId;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = _AccPosts.Title;
                cmd.Parameters.Add("@RoomType", SqlDbType.VarChar).Value = _AccPosts.RoomType;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = _AccPosts.Address;
                cmd.Parameters.Add("@City", SqlDbType.VarChar).Value = _AccPosts.City;
                cmd.Parameters.Add("@StateId", SqlDbType.Int).Value = _AccPosts.StateId;
                cmd.Parameters.Add("@CountryId", SqlDbType.Int).Value = _AccPosts.CountryId;
                cmd.Parameters.Add("@ZipCode", SqlDbType.Int).Value = _AccPosts.ZipCode;
                cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = _AccPosts.Description;

                SqlParameter outputIdParam = new SqlParameter("@OutPut", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outputIdParam);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                Status = int.Parse(outputIdParam.Value.ToString());

                return Status;
            }
            catch (WebException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}