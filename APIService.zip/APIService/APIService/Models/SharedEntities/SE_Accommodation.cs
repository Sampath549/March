﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIService.Models.SharedEntities
{
    public class SE_Accommodation
    {
        public int AccommodationId { get; set; }
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailCheck { get; set; }
        public string MobileCheck { get; set; }
        public string Title { get; set; }
        public string RoomType { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string StateId { get; set; }
        public string StateCode { get; set; }
        public string StateDesc { get; set; }
        public string CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryDesc { get; set; }
        public string ZipCode { get; set; }
        public string Description { get; set; }
        public DateTime CreatedDate { get; set; }
        public string DateLongString { get; set; }
    }
}