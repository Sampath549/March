﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIService.Models.SharedEntities
{
    public class SE_SingleVal
    {
        public string TextValue { get; set; }
    }
}