﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIService.Models.SharedEntities
{
    public class SE_AssignedMenus
    {
        public int? AssignedMenuId { get; set; }
        public int? ParentId { get; set; }
        public string ParentHeader { get; set; }
        public int? RoleId { get; set; }
        public string RoleDesc { get; set; }
    }
}