﻿$(document).ready(function () {
    GetTable();

    $("#btnMenusRecord").click(function () {
        var url = $(this).data("url");
        $.get(url, function (data) {
            $('#CreateMenuData').html(data);
            $('#CreateMenuModel').modal('show');
        });
    });

    $('#tblGetMenus').on("click", ".editMenus", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        $.get(url, function (data) {
            $('#EditMenuData').html(data);
            $('#EditMenuModel').modal('show');
        });
    });

    $('#tblGetMenus').on("click", ".deleteMenus", function (event) {
        event.preventDefault();
        var url = $(this).attr("href");
        var id = getURLParameter(url, 'id'); // calling another function

        swal({
            title: "Are you sure?",
            text: "This will delete the Record",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Delete it!",
            closeOnConfirm: false
        },
        function (isConfirm) {
            $(".loadingImg").show();
            if (isConfirm) {
                $.ajax({
                    url: '/CPanelDev/DeleteMenus',
                    type: 'POST',
                    data: JSON.stringify({ "IdVal": id }),
                    contentType: 'application/json; charset=utf-8;',
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                    }
                });
            }
            $(".loadingImg").hide();
        }
    );
    });
});

function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url) || [, null])[1];
}

function GetTable() {
    Table = $('#tblGetMenus').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelDev/GetMenusGrid',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",

        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter ParentId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "TextCenter Header", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "20%", "sClass": "TextCenter Controller", "render": function (data, type, row) { return (row[2]); } },
            { "sWidth": "20%", "sClass": "TextCenter Action", "render": function (data, type, row) { return (row[3]); } },
            { "sWidth": "10%", "sClass": "TextCenter HavingChild", "render": function (data, type, row) { return (row[4]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelDev/EditMenus?id=' + row[0] + '"  class="editMenus" title="Edit" return false;> <i class="glyphicon glyphicon-edit"></i></a>&nbsp;&nbsp;<a href="/CPanelDev/DeleteMenus?id=' + row[0] + '" class="deleteMenus" title="Delete" return false;> <i class="glyphicon glyphicon-trash"></i></a>&nbsp;&nbsp;</center>';
                }, "targets": 0,
            }
        ],
    });
}
