﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please Select an Option.");

$(document).ready(function () {
    $("#AccPostsDetails").validate({
        rules: {
            'Title': {
                required: true,
                minlength: 3,
                maxlength: 30
            },
            'RoomType': {
                selectNone: true
            },
            'Address': {
                required: true,
                minlength: 3,
                maxlength: 50
            },
            'City': {
                required: true,
                minlength: 2,
                maxlength: 30
            },
            'StateId': {
                selectNone: true
            },
            'CountryId': {
                selectNone: true
            },
            'ZipCode': {
                required: true,
                numbersonly: true,
                maxlength: 10
            },
            'Description': {
                required: true,
                minlength: 3,
                maxlength: 300
            }
        },
        messages: {
            'Title': {
                required: 'Please Enter Title',
                minlength: 'Must enter Minimum of 3 characters'
            },
            'Address': {
                required: 'Please Enter Address',
                minlength: 'Must enter Minimum of 3 characters'
            },
            'City': {
                required: 'Please Enter City',
                minlength: 'Must enter Minimum of 2 characters'
            },
            'ZipCode': {
                required: 'Please Enter ZipCode'
            },
            'Description': {
                required: 'Please Enter Description'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                var _postData = {
                    Title: $('#Title').val(),
                    RoomType: $('#RoomType').val(),
                    Address: $('#Address').val(),
                    City: $('#City').val(),
                    StateId: $('#StateId').val(),
                    CountryId: $('#CountryId').val(),
                    ZipCode: $('#ZipCode').val(),
                    Description: $('#Description').val()
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelUser/InsertAccPosts",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});