﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");

$(document).ready(function () {
    $("#SubMenuDetails").validate({
        rules: {
            'ParentId': {
                selectNone: true
            },
            'Header': {
                required: true,
                minlength: 3,
                lettersonly: true
            },
            'Controller': {
                required: true,
                minlength: 3,
                lettersonly: true
            },
            'Action': {
                required: true,
                minlength: 3,
                lettersonly: true
            },
            'Order': {
                required: true,
                numbersonly: true
            }
        },
        messages: {
            'ParentId': {
                selectNone: 'Please Select Parent Menu',
            },
            'Header': {
                required: 'Please Enter a Header',
                minlength: 'Must enter Minimum of 3 characters'
            },
            'Controller': {
                required: 'Please Enter a Controller',
                minlength: 'Must enter Minimum of 3 characters'
            },
            'Action': {
                required: 'Please Enter a Action',
                minlength: 'Must enter Minimum of 3 characters'
            },
            'HavingChild': {
                required: 'Please Select Yes / No'
            },
            'Order': {
                required: 'Please Enter a Order'
            },
            'Icon': {
                required: 'Please Enter a Icon'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {

                var _postData;
                if ($('#btnSubMenu').val() == 'Save') {
                    _postData = {
                        ParentId: $('#ParentId').val(),
                        Header: $('#Header').val(),
                        Controller: $('#Controller').val(),
                        Action: $('#Action').val(),
                        Order: $('#Order').val()
                    };
                }
                else if ($('#btnSubMenu').val() == 'Update') {
                    _postData = {
                        ChildId: $('#ChildId').val(),
                        ParentId: $('#ParentId').val(),
                        Header: $('#Header').val(),
                        Controller: $('#Controller').val(),
                        Action: $('#Action').val(),
                        Order: $('#Order').val()
                    };
                }

                $.ajax({
                    type: "POST",
                    url: "/CPanelDev/InsertUpdateSubMenus",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreateSubMenuModel").modal('show');
                        }
                        else {
                            $("#CreateSubMenuModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelDev/CreateSubMenus";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});