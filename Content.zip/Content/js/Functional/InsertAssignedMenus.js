﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");

$(document).ready(function () {
    $("#AssignedMenuDetails").validate({
        rules: {
            'ParentId': {
                selectNone: true
            },
            'RoleId': {
                selectNone: true
            }
        },
        messages: {
            'ParentId': {
                selectNone: 'Please Select Parent Menu',
            },
            'RoleId': {
                selectNone: 'Please Select Role',
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {

                var _postData;
                if ($('#btnAssignedMenu').val() == 'Save') {
                    _postData = {
                        ParentId: $('#ParentId').val(),
                        RoleId: $('#RoleId').val()
                    };
                }
                else if ($('#btnAssignedMenu').val() == 'Update') {
                    _postData = {
                        AssignedMenuId: $('#AssignedMenuId').val(),
                        ParentId: $('#ParentId').val(),
                        RoleId: $('#RoleId').val()
                    };
                }

                $.ajax({
                    type: "POST",
                    url: "/CPanelDev/InsertUpdateAssignedMenus",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                            $("#CreateSubMenuModel").modal('show');
                        }
                        else {
                            $("#CreateSubMenuModel").modal('hide');
                            swal({
                                title: response.Caption,
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = "/CPanelDev/CreateAssignedMenus";
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.responseText);
                    }
                });
            }, 0);
        }
    });
});